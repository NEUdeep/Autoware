Fill-out only one section depending on whether you are reporting a bug or a new feature.

# Bug
## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Problem

  1.
  1.
  1.

## Specifications

  - Ubuntu version:
  - ROS version:
  - Autoware branch:

# New Feature
Describe where the new feature request comes from. Add a high-level diagram of how the new feature should work.
